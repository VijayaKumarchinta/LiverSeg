# LiverSegAI — Clinical Liver Segmentation AI Workstation

LiverSegAI is an enterprise-grade medical imaging and computer vision platform designed for radiologists, clinicians, researchers, and administrators. The platform performs AI-based liver and lesion segmentations from abdominal CT scans (DICOM, NIfTI formats) and compiles interactive compliance dashboards.

---

## 🛠️ System Prerequisites & Configuration

### 1. Root Environment Settings (`.env`)
Create a `.env` file at the root of the project. A template is provided in `.env.example`:

```env
# PostgreSQL Database Settings
DB_NAME=liverseg_db
DB_USER=liverseg_user
DB_PASSWORD=your_db_password
DB_HOST=127.0.0.1
DB_PORT=5432

# Frontend Environment Variables
VITE_API_URL=http://localhost:8000/api
```

---

## 🐍 Backend Setup (Django)

The backend uses Django, Django REST Framework, and SimpleJWT.

1. **Navigate to backend and active virtual environment:**
   ```powershell
   cd backend
   # For Windows:
   .\venv\Scripts\activate
   ```
2. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Verify Settings & Database Connectivity:**
   Ensure your local PostgreSQL database is running and credentials match the `.env` values. Run the system check:
   ```bash
   python manage.py check
   ```
4. **Apply Migrations:**
   ```bash
   python manage.py showmigrations
   python manage.py migrate
   ```
5. **Start Django Development Server:**
   ```bash
   python manage.py runserver
   ```

## ⚡ Frontend Setup (Vue 3 / Vite)

The frontend workstation is built using Vue 3, Pinia, Vue Router, TailwindCSS, and Axios.

1. **Navigate to the frontend directory:**
   ```bash
   cd frontend
   ```
2. **Install Node modules:**
   ```bash
   npm install
   ```
3. **Start Dev Server:**
   ```bash
   npm run dev
   ```
4. **Production Build Compilation:**
   ```bash
   npm run build
   ```

---

## 🔒 Security Operations

- **Password Reset (`reset_password`):**
  The simplified password reset action is constrained strictly to development mode. It will only execute if `DEBUG = True` is configured in `backend/core/settings.py`. In production, a secure, token-based verification flow via email must be integrated.

---

## 🚀 Production Deployment

LiversegAI is containerized with Docker to ensure a smooth transition to production servers.

### 1. Package the Application (Windows)
Run the PowerShell script to safely bundle your source code while excluding development secrets and unnecessary files.
```powershell
.\deploy_prep.ps1
```
This will output `liverseg_production.zip`. You can transfer this archive to your production server and extract it. (Mac/Linux users can use `./deploy_prep.sh`).

### 2. Configure Production Secrets
On your production server, create a secure `.env` file (never commit this file!). A template is provided in `.env.example`.
Make sure you set a secure `SECRET_KEY`, and change `DB_PASSWORD`.

### 3. Deploy with Docker Compose
The `docker-compose.yml` file is configured with 4 services: a PostgreSQL database, a Redis cache/broker, the Django backend, the Celery worker, and the Nginx frontend reverse-proxy.

```bash
docker-compose up -d --build
```

**Note:** Nginx automatically serves the frontend on port `80` and proxies `/api/` traffic to the backend, while also directly serving collected static files and uploaded media assets.

---

## ⚡ Vercel Deployment (Frontend Only)

You can deploy the Vite frontend to Vercel for fast, globally-distributed delivery, while hosting your backend services elsewhere.

### 1. Configure the Frontend for Vercel
We have configured `vercel.json` to handle client-side routing. Vercel will route all page refreshes (e.g. `/dashboard`) to `index.html` automatically.

### 2. Import to Vercel
1. Push your code to a Git repository (GitHub, GitLab, or Bitbucket).
2. Connect your Git repository to Vercel.
3. In the Vercel project configuration:
   - **Framework Preset**: Vite
   - **Root Directory**: `.` (default)
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Add the following **Environment Variable** in the Vercel project settings:
   - `VITE_API_URL`: `https://your-backend-api-url.com/api` (the URL of your deployed Django backend).

### 3. Deploy the Backend (Required)
Since Vercel is serverless and frontend-only, it cannot run the Django server, PostgreSQL database, Redis, or Celery. You must deploy your backend separately.

Recommended backend hosting platforms:
- **Railway** / **Render**: Support multi-container setups natively. You can deploy your PostgreSQL database, Redis, Django API, and Celery workers easily using Docker Compose or individual web/worker services.
- **Cloud VPS (DigitalOcean / AWS EC2 / Hetzner)**: You can copy your `liverseg_production.zip` package using our scripts, extract it, and run `docker-compose up -d --build` directly on the server.

> [!WARNING]
> Remember to add your Vercel deployment URL (e.g. `https://liverseg-ai.vercel.app`) to the `CORS_ALLOWED_ORIGINS` environment variable on your backend server so that the frontend is authorized to make API calls!

